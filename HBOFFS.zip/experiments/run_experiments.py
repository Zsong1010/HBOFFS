import os
import pandas as pd
import numpy as np
import sys

# Add the project root directory to the path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_split.random_split import random_split
from data_split.distribution_split import distribution_split
from feature_selection.hboffs import hboffs_federated_feature_selection
from feature_selection.ic_hbo import ic_hbo_feature_selection
from federated.homomorphic_encryption import PaillierHomomorphicEncryption
from federated.smpc import SMPC
from federated.client import FederatedClient
from federated.server import FederatedServer
from classifiers.knn import knn_classify
from classifiers.svm import svm_classify
from classifiers.xgboost_2 import xgb_classify
from classifiers.fs_classify import fs_classify
from experiments.evaluation import timeit
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import VarianceThreshold, SelectKBest, mutual_info_classif
import matplotlib.pyplot as plt

# Import new preprocessing module
try:
    from data_preprocessing.joint_sampling_imputer import apply_joint_sampling_imputation

    JOINT_SAMPLING_AVAILABLE = True
except ImportError:
    print("Warning: Multilevel joint sampling imputation module not found, using traditional methods")
    JOINT_SAMPLING_AVAILABLE = False

# Set experiment parameters
# data_dir = '../DataSet'  # Dataset folder
# Set experiment parameters
# Use absolute path to ensure data files can be found no matter where the code is run
data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
M = 5  # Number of clients
n_runs = 30  # Number of experiment repetitions
max_iter = 50  # Maximum iterations for feature selection
pop_size = 50  # Population size for feature selection



# Classifier mapping
def get_classifier(name):
    if name == 'knn':
        return knn_classify
    elif name == 'svm':
        return svm_classify
    elif name == 'xgboost':
        return xgb_classify
    else:
        raise ValueError('Unknown classifier')


# Fitness function example: Measure feature subset using cross-validation accuracy
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier

def fitness_func(X, y, mask):
    if np.sum(mask) == 0:
        return 0
    X_sel = X[:, mask == 1]
    from sklearn.model_selection import cross_val_predict
    from sklearn.metrics import accuracy_score, f1_score
    clf = KNeighborsClassifier(n_neighbors=3)
    y_pred = cross_val_predict(clf, X_sel, y, cv=3)
    acc = accuracy_score(y, y_pred)
    f1 = f1_score(y, y_pred, average='macro')
    penalty = 0.01 * (np.sum(mask) / len(mask))
    return 0.7 * acc + 0.3 * f1 - penalty


# Main experiment flow
def run_experiment(dataset_name, split_method, fs_method, classifier_name):
    """
    Single experiment flow.
    """
    # 1. Load data
    df = pd.read_csv(os.path.join(data_dir, dataset_name))
    label_col = df.columns[-1]
    # Encode all non-numeric features using LabelEncoder
    from sklearn.preprocessing import LabelEncoder
    for col in df.columns[:-1]:  # Do not process the label column
        if df[col].dtype == 'object':
            df[col] = LabelEncoder().fit_transform(df[col])
    X = df.iloc[:, :-1].values
    y = df.iloc[:, -1].values  # Fixed: take the last column as the label
    y = LabelEncoder().fit_transform(y)

    # === Feature preprocessing ===
    # Check for missing values
    has_missing = np.any(np.isnan(X))

    if has_missing and JOINT_SAMPLING_AVAILABLE:
        print("[Preprocessing] Missing values detected, using multilevel joint sampling imputation strategy...")
        # Use multilevel joint sampling imputation strategy
        X = apply_joint_sampling_imputation(X, n_samples=5, covariance_threshold=0.8)
        print("[Preprocessing] Multilevel joint sampling imputation completed")
    else:
        print("[Preprocessing] Using traditional missing value imputation method...")
        # Traditional method: mean imputation
        imputer = SimpleImputer(strategy='mean')
        X = imputer.fit_transform(X)

    # Standardization
    scaler = StandardScaler()
    X = scaler.fit_transform(X)

    # Feature selection: first, use variance threshold
    selector_var = VarianceThreshold(threshold=0.01)
    X = selector_var.fit_transform(X)

    # Then, use mutual information to select features, keeping the top max(20, X.shape[1]//2) features
    kbest = min(max(20, X.shape[1] // 2), X.shape[1])
    selector_mi = SelectKBest(mutual_info_classif, k=kbest)
    X = selector_mi.fit_transform(X, y)

    # 2. Data splitting
    random_state = 20
    if split_method == 'random':
        subsets = random_split(pd.DataFrame(np.hstack([X, y.reshape(-1, 1)])), M, random_state)
    elif split_method == 'distribution':
        subsets = distribution_split(pd.DataFrame(np.hstack([X, y.reshape(-1, 1)])), M, X.shape[1], random_state)
    else:
        raise ValueError('Unknown data split method')

    # 3. Construct client data
    clients_data = []
    for subset in subsets:
        X_c = subset.iloc[:, :-1].values
        y_c = subset.iloc[:, -1].values
        clients_data.append({'X': X_c, 'y': y_c})

    # 4. Initialize encryption and SMPC
    encryption = PaillierHomomorphicEncryption(key_length=2048)
    smpc = SMPC(n_clients=M)

    # 5. Federated feature selection
    results = []
    best_acc_list = []  # Record the best accuracy for each iteration
    feature_weights = None
    feature_indices = None

    if fs_method == 'hboffs':
        # Update call to get weight matrix and feature indices
        masks, feature_weights, feature_indices, agg_weights, agg_indices = hboffs_federated_feature_selection(
            clients_data, pop_size, max_iter, fitness_func, encryption, smpc, random_state
        )

        # Record the best accuracy for each client
        for i, client in enumerate(clients_data):
            mask, _, acc_list = ic_hbo_feature_selection(client['X'], client['y'], pop_size, max_iter, fitness_func,
                                                         random_state)
            best_acc_list.append(acc_list)  # Record accuracy for all iterations
            best_acc = max(acc_list)
            results.append({'acc': best_acc, 'recall': 0, 'f1': 0, 'time': 0})

        # Print feature analysis results
        if feature_weights is not None and feature_indices is not None:
            print(f"\n[Feature Analysis Results]")
            print(f"Final selected features: {len(feature_indices['final_selected_features'])}")
            print(f"Top 5 most important feature indices: {feature_indices['top_features'][:5]}")
            print(f"Feature weight range: [{np.min(feature_weights):.4f}, {np.max(feature_weights):.4f}]")

            # Print aggregation results
            if agg_weights is not None and agg_indices is not None:
                print(f"\n[Aggression Results]")
                print(f"Aggregated feature weight range: [{np.min(agg_weights):.4f}, {np.max(agg_weights):.4f}]")
                print(f"Number of consensus features: {len(agg_indices['consensus_features'])}")
                print(f"Number of clients: {agg_indices['n_clients']}")

                # Output aggregation accuracy
                if 'final_selected_features' in feature_indices:
                    n_final_features = len(feature_indices['final_selected_features'])
                    print(f"\n[Final Results]")
                    print(f"Final selected features: {n_final_features}")
                    print(f"Final selected feature indices: {feature_indices['final_selected_features']}")
                    if 'final_feature_weights' in feature_indices:
                        final_weights = feature_indices['final_feature_weights']
                        print(f"Final feature weights: {[f'{w:.4f}' for w in final_weights]}")
                        print(f"Final feature weight sum: {sum(final_weights):.4f}")
    else:
        raise ValueError('Unknown feature selection method')

    # 6. Train/evaluate classifier
    clf_func = get_classifier(classifier_name)
    results = []
    for i, client in enumerate(clients_data):
        # Construct DataFrame with the last column as label
        X_c = client['X']
        y_c = client['y']
        df_c = pd.DataFrame(np.hstack([X_c, y_c.reshape(-1, 1)]))
        from time import time
        start = time()
        acc, recall, f1 = fs_classify(masks[i], df_c, classifier_name.upper())
        elapsed = time() - start
        results.append({'acc': acc, 'recall': recall, 'f1': f1, 'time': elapsed})

    return results, best_acc_list, feature_weights, feature_indices


# Main multiple experiment controller
def main():
    # Only use NSL-KDD dataset
    datasets = ['NSL-KDD_train.csv']
    # datasets = ['Ionosphere.csv']
    split_methods = ['random']
    # fs_methods = ['hboffs']
    fs_methods = ['hboffs']
    # classifiers = ['knn']
    classifiers = ['xgboost']
    all_results = []
    best_acc_lists = {'hboffs': []}

    for dataset in datasets:
        for split_method in split_methods:
            for fs_method in fs_methods:
                for clf in classifiers:
                    for run in range(n_runs):
                        results, best_acc_list, feature_weights, feature_indices = run_experiment(dataset, split_method,
                                                                                                  fs_method, clf)
                        best_acc_lists[fs_method].append(best_acc_list)
                        for i, res in enumerate(results):
                            all_results.append({
                                'dataset': dataset,
                                'split': split_method,
                                'fs': fs_method,
                                'clf': clf,
                                'run': run,
                                'client': i,
                                **res
                            })
                        print(f"Completed: {dataset} | {split_method} | {fs_method} | {clf} | run {run}")


if __name__ == '__main__':
    main()
