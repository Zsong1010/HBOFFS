from sklearn.metrics import accuracy_score, recall_score, f1_score
import time

def evaluate_metrics(y_true, y_pred):
    """
    Calculate accuracy, recall, and F1-score.
    Parameters:
        y_true: True labels
        y_pred: Predicted labels
    Returns:
        acc, recall, f1: Classification accuracy, recall, F1-score
    """
    acc = accuracy_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred, average='macro')
    f1 = f1_score(y_true, y_pred, average='macro')
    return acc, recall, f1


def timeit(func):
    """
    Runtime statistics decorator.
    Usage: @timeit
    """
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        elapsed = end - start
        return result, elapsed
    return wrapper
