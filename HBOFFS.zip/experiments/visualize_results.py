import pandas as pd
import matplotlib.pyplot as plt


def calculate_average_metrics(results):
    """
    Calculate average accuracy, recall, and F1-score from the results.
    """
    df = pd.DataFrame(results)
    avg_acc = df['acc'].mean()
    avg_recall = df['recall'].mean()
    avg_f1 = df['f1'].mean()
    return avg_acc, avg_recall, avg_f1
