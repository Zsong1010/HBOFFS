import pandas as pd
import numpy as np
from typing import List

def distribution_split(df: pd.DataFrame, M: int, label_col: str, random_state: int = None) -> List[pd.DataFrame]:
    """
    After grouping by class, randomly split each class's samples into M subsets,
    and then combine the subsets from each class, ensuring that each client has a diverse class distribution.
    Parameters:
        df: The input pandas DataFrame
        M: The number of clients, i.e., the number of subsets to split into
        label_col: The column name for labels
        random_state: The random seed to ensure reproducibility of the experiment
    Returns:
        List[pd.DataFrame], where each element is a subset for a client
    """
    if random_state is not None:
        np.random.seed(random_state)
    # Store data for each client
    subsets = [[] for _ in range(M)]
    # Group by class
    grouped = df.groupby(label_col)
    for _, group in grouped:
        # Shuffle the indices of the current class
        indices = np.random.permutation(group.index)
        # Uniformly split the indices of the current class
        splits = np.array_split(indices, M)
        # Assign to each client
        for i in range(M):
            subsets[i].append(group.loc[splits[i]])
    # Combine all class subsets for each client
    result = [pd.concat(subset).reset_index(drop=True) for subset in subsets]
    return result
