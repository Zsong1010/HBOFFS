import pandas as pd
import numpy as np
from typing import List

def random_split(df: pd.DataFrame, M: int, random_state: int = None) -> List[pd.DataFrame]:
    """
    Randomly and evenly split the input DataFrame into M subsets.
    Parameters:
        df: The input pandas DataFrame
        M: The number of clients, i.e., the number of subsets to split into
        random_state: The random seed to ensure reproducibility of the experiment
    Returns:
        List[pd.DataFrame], where each element is a subset
    """
    if random_state is not None:
        np.random.seed(random_state)
    # Shuffle the indices
    shuffled_indices = np.random.permutation(df.index)
    # Uniformly split the indices
    splits = np.array_split(shuffled_indices, M)
    # Generate subsets based on the indices
    subsets = [df.loc[split].reset_index(drop=True) for split in splits]
    return subsets
