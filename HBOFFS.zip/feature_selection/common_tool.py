import numpy as np

def binary_func(x, threshold=0.5, method='sigmoid', k=0):
    """
    Supports multiple binarization strategies:
    - method='sigmoid': Sigmoid + threshold
    - method='topk': Top-K selection (k is a positive integer, indicating the top k largest)
    - method='quantile': Quantile threshold
    """
    if method == 'sigmoid':
        x = np.clip(x, -50, 50)
        return 1 if 1 / (1 + np.exp(-x)) > threshold else 0
    elif method == 'topk':
        # x should be a vector, k is a positive integer
        if k <= 0 or k > len(x):
            raise ValueError('k must be in 1~len(x)')
        idx = np.argsort(-x)[:k]
        mask = np.zeros_like(x)
        mask[idx] = 1
        return mask
    elif method == 'quantile':
        # x is a vector, threshold is the quantile (0~1)
        q = np.quantile(x, threshold)
        return (x >= q).astype(int)
    else:
        raise ValueError('Unknown binarization method')

def bound_check(x, r_max, r_min):
    """
    Boundary check, ensuring that x is within the range [r_min, r_max], supports scalars and arrays
    """
    return np.clip(x, r_min, r_max)
