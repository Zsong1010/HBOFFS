import numpy as np
import random
from .common_tool import binary_func, bound_check
from joblib import Parallel, delayed

r_max = 10
r_min = -10

def cauchy_sample(r_max, r_min, size=1, scale=1.0):
    """Cauchy distribution sampling, center at the midpoint of the interval, scale controls tail thickness"""
    center = (r_max + r_min) / 2
    width = (r_max - r_min) / 2
    return np.random.standard_cauchy(size) * width * 0.1 * scale + center


def sigmoid(x):
    return 2 * (1.0 / (1.0 + np.exp(-x)) - 0.5)


def immune_clone_pool(elites, dim, g_best_fit, iter_count, max_iter, r_max, r_min, fitness_func, X, y, pop_size, pos_time_bpos_fit, beta, min_clone_b, binary_kwargs=None, cauchy_scale_iter=1.0):
    """
    Immune clone pool for the maintainer subgroup:
    - Clone number Nc is calculated as Nc = sum_{i=1..m} round(beta * m / i + b) (approximately distributed among elite individuals)
    - Adaptive immune mutation: sigmoid probability, updated according to the P_i(t+1) rule
    """
    clones = []
    m = len(elites)
    # Calculate the number of clones for each elite (based on ranking)
    rank_clone_nums = [max(1, int(round(beta * m / (idx + 1) + min_clone_b))) for idx in range(m)]
    for ind_rank, ind in enumerate(elites):
        for _ in range(rank_clone_nums[ind_rank]):
            clone = ind.copy()
            # Adaptive immune mutation: apply sigmoid probability to decide whether to execute the update as in Eq.(4)
            for j in range(dim):
                p_mut = sigmoid(clone[j])
                if random.random() < p_mut:
                    val = clone[j]
                    inv = 1.0 / (val + 1e-8)
                    clone[j] = bound_check(val + inv, r_max, r_min)
            # Binarize and evaluate
            for j in range(dim):
                if binary_kwargs:
                    clone[dim + 1 + j] = binary_func(clone[j], **binary_kwargs)
                else:
                    clone[dim + 1 + j] = binary_func(clone[j])
            mask = clone[dim + 1:dim * 2 + 1]
            clone[-1] = fitness_func(X, y, mask)
            clones.append(clone)
    # Introduce a small number of non-elite individuals for diversity enhancement (Cauchy disturbance)
    non_elite_idx = np.arange(m, pos_time_bpos_fit.shape[0])
    for _ in range(int(0.15 * pop_size)):
        if len(non_elite_idx) == 0:
            break
        idx = np.random.choice(non_elite_idx)
        ind = pos_time_bpos_fit[idx].copy()
        # Cauchy disturbance increases global jump
        ind[:dim] += cauchy_sample(r_max, r_min, size=dim, scale=cauchy_scale_iter)
        ind[:dim] = bound_check(ind[:dim], r_max, r_min)
        for j in range(dim):
            if binary_kwargs:
                ind[dim + 1 + j] = binary_func(ind[j], **binary_kwargs)
            else:
                ind[dim + 1 + j] = binary_func(ind[j])
        mask = ind[dim + 1:dim * 2 + 1]
        ind[-1] = fitness_func(X, y, mask)
        clones.append(ind)
    return np.array(clones)


def fitness_func(X, y, mask, alpha=0.001, cv=5, n_jobs=-1):
    if np.sum(mask) == 0:
        return 0
    X_sel = X[:, mask == 1]
    from sklearn.model_selection import cross_val_score
    try:
        from xgboost import XGBClassifier
        acc = cross_val_score(XGBClassifier(eval_metric='mlogloss'), X_sel, y, cv=cv, n_jobs=n_jobs).mean()
    except Exception:
        from sklearn.ensemble import RandomForestClassifier
        acc = cross_val_score(RandomForestClassifier(n_estimators=120, random_state=42), X_sel, y, cv=cv, n_jobs=n_jobs).mean()
    feat_num = np.sum(mask)
    dim = len(mask)
    return acc - alpha * (feat_num / dim)


def ic_hbo_feature_selection(
    X,
    y,
    pop_size,
    max_iter,
    fitness_func,
    r_max=10,
    r_min=-10,
    random_state=None,
    binary_kwargs=None,
    patience=20,
    alpha_penalty=0.01,
    # Recommended parameters (easily adjustable)
    beta=0.3,                 # β≈0.3 in the clone formula
    min_clone_b=1,            # Minimum b≥1 for Nc
    alpha_weight=0.1,         # Weight α≈0.1 in Eq.(5)
    p_crossover=0.5,          # Crossover probability
    exchange_period=5,        # Subgroup information exchange period
    cauchy_scale=1.0,         # Cauchy scale
    shrink_ratio=0.9,         # Shrink ratio SR≈0.9, for progressively shrinking disturbance
    memory_bank_ratio=0.1,    # Memory bank ratio MB≈0.1N
):
    """
    IC-HBO (including immune evolution and Cauchy sampling)
    - Maintainers (M): CSA clone + adaptive immune mutation (Eq.3-4)
    - Restorers (R): Weighted random disturbance (Eq.5)
    - Sterile (S): Crossover with M/R + position update (Cauchy/personal best, Eq.6)
    - Subgroup information exchange and offspring generation (every exchange_period rounds)
    Parameter settings: SR=0.9, MB=0.1N, β≈0.3, α≈0.1.
    """
    if random_state is not None:
        np.random.seed(random_state)
        random.seed(random_state)
    dim = X.shape[1]
    # Individuals: [continuous_pos(dim) | self_counter | binary_pos(dim) | fitness]
    pos_time_bpos_fit = np.zeros((pop_size, dim * 2 + 2))
    best_mask = None
    best_fitval = -np.inf
    best_acc_list = []
    # Initialize (diversification + special points)
    for i in range(pop_size):
        for j in range(dim):
            if i == 0:
                pos_time_bpos_fit[i, j] = r_max
            elif i == 1:
                pos_time_bpos_fit[i, j] = r_min
            elif i == 2:
                pos_time_bpos_fit[i, j] = (r_max + r_min) / 2
            else:
                pos_time_bpos_fit[i, j] = np.random.uniform(r_min, r_max)
            if binary_kwargs:
                pos_time_bpos_fit[i, dim + 1 + j] = binary_func(pos_time_bpos_fit[i, j], **binary_kwargs)
            else:
                pos_time_bpos_fit[i, dim + 1 + j] = binary_func(pos_time_bpos_fit[i, j])
        mask = pos_time_bpos_fit[i, dim + 1:dim * 2 + 1]
        fitval = fitness_func(X, y, mask)
        pos_time_bpos_fit[i, -1] = fitval
        if fitval > best_fitval:
            best_fitval = fitval
            best_mask = mask.copy()
    # Sort
    pos_time_bpos_fit = pos_time_bpos_fit[np.argsort(-pos_time_bpos_fit[:, -1])]
    g_best_fit = pos_time_bpos_fit[0, -1]
    g_best_binary_pos = pos_time_bpos_fit[0, dim + 1:dim * 2 + 1].copy()
    no_improve = 0
    last_best = g_best_fit
    memory_bank_size = max(1, int(memory_bank_ratio * pop_size))

    for iter_count in range(max_iter):
        # Dynamically shrink Cauchy scale
        cauchy_scale_iter = cauchy_scale * (shrink_ratio ** iter_count)
        # Subgroup division
        maintainer_num = int(pop_size * 0.34)
        restorer_num = int(pop_size * 0.33)
        sterile_num = pop_size - maintainer_num - restorer_num
        # Maintainer memory pool (MB=0.1N)
        elites = pos_time_bpos_fit[:memory_bank_size]
        # Step1-4: Maintainers: CSA + Immune mutation
        clone_pool = immune_clone_pool(
            elites, dim, g_best_fit, iter_count, max_iter, r_max, r_min,
            fitness_func, X, y, pop_size, pos_time_bpos_fit, beta, min_clone_b,
            binary_kwargs, cauchy_scale_iter=cauchy_scale_iter
        )
        # Step 4: Maintainers select best clones
        if len(clone_pool) > 0:
            best_clone = clone_pool[np.argmax(clone_pool[:, -1])]
            if best_clone[-1] > g_best_fit:
                g_best_fit = best_clone[-1]
                g_best_binary_pos = best_clone[dim + 1:dim * 2 + 1].copy()
        # Restorer: Eq.(5) Weighted random disturbance X^{t+1} = alpha*X^t + (1-alpha)*rand()
        restorer_idx = np.arange(maintainer_num, maintainer_num + restorer_num)
        for index in restorer_idx:
            x_t = pos_time_bpos_fit[index, :dim].copy()
            rand_vec = np.random.uniform(r_min, r_max, size=dim)
            x_next = alpha_weight * x_t + (1 - alpha_weight) * rand_vec
            pos_time_bpos_fit[index, :dim] = bound_check(x_next, r_max, r_min)
            for j in range(dim):
                if binary_kwargs:
                    pos_time_bpos_fit[index, dim + 1 + j] = binary_func(pos_time_bpos_fit[index, j], **binary_kwargs)
                else:
                    pos_time_bpos_fit[index, dim + 1 + j] = binary_func(pos_time_bpos_fit[index, j])
            mask = pos_time_bpos_fit[index, dim + 1:dim * 2 + 1]
            pos_time_bpos_fit[index, -1] = fitness_func(X, y, mask)
        # Sterile: Crossover + Eq.(6) Position update (Cauchy/personal best)
        sterile_idx = np.arange(maintainer_num + restorer_num, pop_size)
        for index in sterile_idx:
            # Crossover with M or R
            if random.random() < 0.5:
                mate = pos_time_bpos_fit[random.randint(0, maintainer_num - 1)]
            else:
                mate = pos_time_bpos_fit[random.randint(maintainer_num, maintainer_num + restorer_num - 1)]
            parent = pos_time_bpos_fit[index]
            if random.random() < p_crossover:
                cp = random.randint(1, dim - 1)
                off = parent.copy()
                off[:cp] = parent[:cp]
                off[cp:dim] = mate[cp:dim]
            else:
                off = parent.copy()
            # Position update (using progressively shrinking Cauchy sampling)
            if random.random() < 0.5:
                x_next = cauchy_sample(r_max, r_min, size=dim, scale=cauchy_scale_iter)
                off[:dim] = bound_check(0.5 * off[:dim] + 0.5 * x_next, r_max, r_min)
            else:
                off[:dim] = bound_check(off[:dim], r_max, r_min)
            # Binarize and evaluate
            for j in range(dim):
                if binary_kwargs:
                    off[dim + 1 + j] = binary_func(off[j], **binary_kwargs)
                else:
                    off[dim + 1 + j] = binary_func(off[j])
            mask = off[dim + 1:dim * 2 + 1]
            off[-1] = fitness_func(X, y, mask)
            if off[-1] > pos_time_bpos_fit[index, -1]:
                pos_time_bpos_fit[index] = off
        # Information exchange and offspring generation (simple implementation)
        if (iter_count + 1) % exchange_period == 0:
            M_best = pos_time_bpos_fit[:maintainer_num][0].copy()
            R_best = pos_time_bpos_fit[maintainer_num:maintainer_num + restorer_num]
            R_best = R_best[np.argmax(R_best[:, -1])].copy()
            S_best = pos_time_bpos_fit[maintainer_num + restorer_num:]
            S_best = S_best[np.argmax(S_best[:, -1])] if len(S_best) > 0 else M_best.copy()
            # Global best
            candidates = [M_best, R_best, S_best]
            gb = candidates[int(np.argmax([c[-1] for c in candidates]))]
            g_best_fit = gb[-1]
            g_best_binary_pos = gb[dim + 1:dim * 2 + 1].copy()
            # Crossover S and R to generate offspring, replace the worst individuals in R and S
            num_off = max(1, sterile_num // 2)
            restorer_idx = np.arange(maintainer_num, maintainer_num + restorer_num)
            for _ in range(num_off):
                if len(sterile_idx) == 0 or len(restorer_idx) == 0:
                    break
                p1 = pos_time_bpos_fit[random.choice(sterile_idx)]
                p2 = pos_time_bpos_fit[random.choice(restorer_idx)]
                cp = random.randint(1, dim - 1)
                child = p1.copy()
                child[:cp] = p1[:cp]
                child[cp:dim] = p2[cp:dim]
                child[:dim] = bound_check(child[:dim] + np.random.normal(0, 0.05, size=dim), r_max, r_min)
                for j in range(dim):
                    if binary_kwargs:
                        child[dim + 1 + j] = binary_func(child[j], **binary_kwargs)
                    else:
                        child[dim + 1 + j] = binary_func(child[j])
                mask = child[dim + 1:dim * 2 + 1]
                child[-1] = fitness_func(X, y, mask)
                # Replace the worst individual
                worst_idx_R = restorer_idx[np.argmin(pos_time_bpos_fit[restorer_idx][:, -1])]
                worst_idx_S = sterile_idx[np.argmin(pos_time_bpos_fit[sterile_idx][:, -1])] if len(sterile_idx) > 0 else None
                pos_time_bpos_fit[worst_idx_R] = child
                if worst_idx_S is not None:
                    pos_time_bpos_fit[worst_idx_S] = child
        # Selection and record
        pos_time_bpos_fit = pos_time_bpos_fit[np.argsort(-pos_time_bpos_fit[:, -1])]
        current_best = pos_time_bpos_fit[0]
        if current_best[-1] > g_best_fit:
            g_best_fit = current_best[-1]
            g_best_binary_pos = current_best[dim + 1:dim * 2 + 1].copy()
        best_mask_iter = g_best_binary_pos.astype(int)
        # Use external fitness as convergence indicator (no alpha parameter imposed, automatically compatible)
        try:
            fit_now = fitness_func(X, y, best_mask_iter)
        except TypeError:
            fit_now = fitness_func(X, y, best_mask_iter, alpha=0)
        if fit_now > best_fitval:
            best_fitval = fit_now
            best_mask = best_mask_iter.copy()
        best_acc_list.append(best_fitval)
        if abs(g_best_fit - last_best) < 1e-6:
            no_improve += 1
        else:
            no_improve = 0
        last_best = g_best_fit
        if no_improve >= patience:
            break
    # Return
    return best_mask, g_best_fit, best_acc_list
