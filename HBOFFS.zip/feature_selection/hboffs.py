import numpy as np
import pandas as pd
from typing import List, Callable, Dict
from .ic_hbo import ic_hbo_feature_selection
from classifiers.fs_classify import fs_classify
from xgboost import XGBClassifier
from sklearn.model_selection import cross_val_score
from federated.server import FederatedServer


def eval_mask(mask, X_all, y_all, cv=5):
    X_sel = X_all[:, mask == 1]
    if np.sum(mask) == 0:
        return 0

    try:
        # Try using XGBoost
        from xgboost import XGBClassifier
        clf = XGBClassifier(eval_metric='mlogloss', random_state=42)
        acc = cross_val_score(clf, X_sel, y_all, cv=cv).mean()
    except Exception as e:
        # If XGBoost fails, use an alternative classifier
        try:
            from sklearn.ensemble import RandomForestClassifier
            clf = RandomForestClassifier(n_estimators=100, random_state=42)
            acc = cross_val_score(clf, X_sel, y_all, cv=cv).mean()
        except:
            # Last fallback: use simple KNN
            from sklearn.neighbors import KNeighborsClassifier
            clf = KNeighborsClassifier(n_neighbors=3)
            acc = cross_val_score(clf, X_sel, y_all, cv=cv).mean()

    return acc


def generate_feature_weights_and_indices(masks, X_all, y_all):
    """
    Generate feature subset weight matrix and corresponding feature indices

    Parameters:
    masks: Feature selection masks from all clients
    X_all: All data
    y_all: All labels

    Returns:
    feature_weights: Feature weight matrix
    feature_indices: Feature index dictionary
    """
    # Ensure masks are numpy arrays
    if isinstance(masks, list):
        masks = np.array(masks)

    n_clients, n_features = masks.shape

    # Calculate the frequency of each feature
    feature_frequency = np.sum(masks, axis=0) / n_clients

    # Calculate the importance score for each feature (based on XGBoost feature importance)
    feature_importance = np.zeros(n_features)
    try:
        from xgboost import XGBClassifier
        clf = XGBClassifier(eval_metric='mlogloss', random_state=42)
        clf.fit(X_all, y_all)
        if hasattr(clf, 'feature_importances_'):
            feature_importance = clf.feature_importances_
    except:
        # If XGBoost fails, use variance as importance
        feature_importance = np.var(X_all, axis=0)

    # Calculate the feature weight matrix (combining frequency and importance)
    feature_weights = feature_frequency * feature_importance

    # Normalize the weights
    if np.sum(feature_weights) > 0:
        feature_weights = feature_weights / np.sum(feature_weights)

    # Generate feature index dictionary
    feature_indices = {
        'selected_features': np.where(masks[-1] == 1)[0].tolist(),  # Final selected feature indices
        'feature_weights': feature_weights.tolist(),  # Feature weights (renamed to match server's expectations)
        'all_feature_weights': feature_weights.tolist(),  # All feature weights
        'feature_frequency': feature_frequency.tolist(),  # Feature selection frequency
        'feature_importance': feature_importance.tolist(),  # Feature importance
        'top_features': np.argsort(-feature_weights)[:min(20, n_features)].tolist()  # Top 20 most important features
    }

    return feature_weights, feature_indices


def hboffs_federated_feature_selection(clients_data: List[Dict], pop_size: int, max_iter: int,
                                       fitness_func: Callable, encryption, smpc, random_state=None, verbose=True):
    """
    HBOFFS Federated Feature Selection main process, integrating IC-HBO algorithm and multi-client cooperation strategy (MCCES).
    Extreme aggregation strategy: dynamically select the optimal mask in the range [1, n_features], using XGBoost accuracy, ensuring global optimal accuracy and minimal number of features.
    """
    M = len(clients_data)
    n_features = clients_data[0]['X'].shape[1]
    masks = []
    feature_weights_list = []
    feature_indices_list = []

    if verbose:
        print(f"[Federated Feature Selection] Starting with {M} clients, each with {n_features} features")

    # 1. Each client runs IC-HBO locally to select feature subsets
    for i, client in enumerate(clients_data):
        if verbose:
            print(f"[Client {i + 1}] Running IC-HBO feature selection locally...")

        # Split training/test data (80/20 ratio) inside the function
        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(
            client['X'], client['y'], test_size=0.2, random_state=random_state, stratify=client['y']
        )

        # Perform feature selection using training data
        mask, *_ = ic_hbo_feature_selection(X_train, y_train, pop_size, max_iter, fitness_func, random_state)
        masks.append(mask)

        # Calculate feature weights and indices
        feature_weights, feature_indices = generate_feature_weights_and_indices([mask], X_train, y_train)
        feature_weights_list.append(feature_weights)
        feature_indices_list.append(feature_indices)

        if verbose:
            print(f"[Client {i + 1}] Local optimal feature subset: {np.sum(mask)} features selected")

    masks = np.array(masks)

    # === New: Generate feature subset weight matrix and feature indices ===
    if verbose:
        print("[Feature Analysis] Generating feature subset weight matrix and feature indices...")

    # Use training data from all clients
    X_all_train = np.vstack([client['X'] for client in clients_data])  # Temporarily use all data
    y_all_train = np.hstack([client['y'] for client in clients_data])

    feature_weights, feature_indices = generate_feature_weights_and_indices(masks, X_all_train, y_all_train)

    if verbose:
        print(
            f"[Feature Analysis] Generated feature weight matrix for {len(feature_indices['selected_features'])} selected features")
        print(f"[Feature Analysis] Top 5 most important feature indices: {feature_indices['top_features'][:5]}")

    # 2. Homomorphic encryption upload feature subsets, weight matrices, and indices, then perform secure multi-party computation (SMPC)
    if verbose:
        print(
            "[Client] Encrypting local feature subsets, weight matrices, and indices and securely sharing with the server...")

    # Prepare client uploads
    client_uploads = []
    for i, (mask, weights, indices) in enumerate(zip(masks, feature_weights_list, feature_indices_list)):
        encrypted_mask = encryption.encrypt(mask)
        encrypted_weights = encryption.encrypt(weights)

        client_uploads.append({
            'encrypted_mask': encrypted_mask,
            'encrypted_weights': encrypted_weights,
            'feature_indices': indices
        })

    if verbose:
        print("[Server] Received encrypted data from all clients, performing SMPC aggregation...")

    # 3. Server-side aggregation using SMPC
    server = FederatedServer(smpc)
    agg_result = server.aggregate_masks_and_weights(client_uploads)

    if verbose:
        print("[Server] Aggregation complete, returning encrypted results to clients for decryption...")

    # 4. Server returns aggregation results, clients decrypt
    agg_mask = encryption.decrypt(agg_result['aggregated_mask_enc'])
    agg_weights = encryption.decrypt(agg_result['aggregated_weights_enc'])
    agg_indices = agg_result['aggregated_indices']

    # --- Extreme aggregation strategy ---
    freq = np.sum(masks, axis=0)
    sorted_idx = np.argsort(-freq)
    best_acc = -1
    best_mask = None
    best_num = 0

    # Evaluate using training data
    for k in range(1, n_features + 1):
        candidate_mask = np.zeros(n_features, dtype=int)
        candidate_mask[sorted_idx[:k]] = 1
        acc = eval_mask(candidate_mask, X_all_train, y_all_train, cv=5)
        if acc > best_acc or (acc == best_acc and k < best_num):
            best_acc = acc
            best_mask = candidate_mask.copy()
            best_num = k

    if verbose:
        print(
            f"[Client] After dynamic aggregation, optimal feature count: {best_num}, aggregation accuracy: {best_acc:.4f}")

    # Update the final feature indices
    feature_indices['final_selected_features'] = np.where(best_mask == 1)[0].tolist()
    feature_indices['final_feature_weights'] = feature_weights[np.where(best_mask == 1)[0]].tolist()

    # Return results including feature weight matrix and indices
    return [best_mask for _ in range(M)], feature_weights, feature_indices, agg_weights, agg_indices
