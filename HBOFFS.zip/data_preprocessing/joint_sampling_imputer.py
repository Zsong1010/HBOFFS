import numpy as np
import pandas as pd
from sklearn.covariance import EmpiricalCovariance
from sklearn.neighbors import NearestNeighbors
from scipy.stats import multivariate_normal


class JointSamplingImputer:
    """
    Multilevel joint sampling imputation strategy [63]
    1. Sampling based on joint distribution
    2. Rough selection based on covariance
    3. Fine-tuning the selected samples
    """

    def __init__(self, n_samples=5, covariance_threshold=0.8, n_neighbors=5):
        self.n_samples = n_samples  # Number of generated samples
        self.covariance_threshold = covariance_threshold  # Covariance filtering threshold
        self.n_neighbors = n_neighbors  # Number of KNN neighbors
        self.fitted = False

    def fit(self, X):
        """Fit the model, compute the joint distribution and covariance matrix"""
        self.X = X.copy()
        self.n_features = X.shape[1]
        self.n_samples_orig = X.shape[0]

        # Compute covariance matrix
        self.covariance = EmpiricalCovariance().fit(X).covariance_

        # Compute mean vector
        self.mean = np.mean(X, axis=0)

        # Compute feature correlations
        self.correlation = np.corrcoef(X.T)

        self.fitted = True
        return self

    def transform(self, X):
        """Impute the data"""
        if not self.fitted:
            raise ValueError("Model is not fitted yet, please call the fit method first.")

        X_filled = X.copy()

        # Find the missing values
        missing_mask = np.isnan(X_filled)

        for i in range(X_filled.shape[0]):
            for j in range(X_filled.shape[1]):
                if missing_mask[i, j]:
                    # Generate candidate samples
                    candidates = self._generate_candidates(X_filled[i], j)

                    # Rough selection based on covariance
                    filtered_candidates = self._covariance_filter(candidates, X_filled[i], j)

                    # Fine-tune the samples
                    final_candidates = self._fine_tune_samples(filtered_candidates, X_filled[i], j)

                    # Select the best sample
                    best_value = self._select_best_candidate(final_candidates, X_filled[i], j)

                    X_filled[i, j] = best_value

        return X_filled

    def _generate_candidates(self, row, missing_idx):
        """Generate candidate samples based on joint distribution"""
        candidates = []

        # Method 1: Sampling based on multivariate normal distribution
        try:
            # Use complete features to calculate the conditional distribution
            complete_mask = ~np.isnan(row)
            if np.sum(complete_mask) > 0:
                complete_features = row[complete_mask]
                complete_cov = self.covariance[np.ix_(complete_mask, complete_mask)]

                if np.linalg.det(complete_cov) > 1e-10:  # Ensure matrix is invertible
                    # Compute conditional mean and variance
                    cov_12 = self.covariance[missing_idx, complete_mask]
                    cov_22_inv = np.linalg.inv(complete_cov)

                    conditional_mean = self.mean[missing_idx] + cov_12 @ cov_22_inv @ (
                                complete_features - self.mean[complete_mask])
                    conditional_var = self.covariance[missing_idx, missing_idx] - cov_12 @ cov_22_inv @ cov_12.T

                    if conditional_var > 0:
                        candidates.extend(np.random.normal(conditional_mean, np.sqrt(conditional_var), self.n_samples))
        except:
            pass

        # Method 2: Sampling based on KNN similar samples
        try:
            complete_mask = ~np.isnan(row)
            if np.sum(complete_mask) > 0:
                X_complete = self.X[:, complete_mask]
                row_complete = row[complete_mask].reshape(1, -1)

                nn = NearestNeighbors(n_neighbors=min(self.n_neighbors, self.n_samples_orig))
                nn.fit(X_complete)
                distances, indices = nn.kneighbors(row_complete)

                for idx in indices[0]:
                    if not np.isnan(self.X[idx, missing_idx]):
                        candidates.append(self.X[idx, missing_idx])
        except:
            pass

        # Method 3: Simple interpolation based on feature correlation
        if len(candidates) < self.n_samples:
            complete_mask = ~np.isnan(row)
            if np.sum(complete_mask) > 0:
                # Find the most correlated complete feature with the missing feature
                correlations = np.abs(self.correlation[missing_idx, complete_mask])
                if len(correlations) > 0:
                    best_feature_idx = np.argmax(correlations)
                    best_feature = complete_mask.nonzero()[0][best_feature_idx]

                    # Weighted interpolation based on correlation
                    weight = correlations[best_feature_idx]
                    candidates.extend([
                        row[best_feature] * weight + self.mean[missing_idx] * (1 - weight) +
                        np.random.normal(0, 0.1 * np.std(self.X[:, missing_idx]))
                        for _ in range(self.n_samples - len(candidates))
                    ])

        # If not enough candidates, fill with mean value
        while len(candidates) < self.n_samples:
            candidates.append(self.mean[missing_idx] + np.random.normal(0, 0.1 * np.std(self.X[:, missing_idx])))

        return np.array(candidates[:self.n_samples])

    def _covariance_filter(self, candidates, row, missing_idx):
        """Rough selection based on covariance"""
        filtered = []

        for candidate in candidates:
            # Compute covariance consistency with existing features
            complete_mask = ~np.isnan(row)
            if np.sum(complete_mask) > 0:
                consistency_score = 0
                for other_idx in np.where(complete_mask)[0]:
                    if other_idx != missing_idx:
                        expected_cov = self.covariance[missing_idx, other_idx]
                        actual_cov = (candidate - self.mean[missing_idx]) * (row[other_idx] - self.mean[other_idx])
                        consistency_score += abs(expected_cov - actual_cov)

                # Keep candidate if consistency score is below threshold
                if consistency_score < self.covariance_threshold:
                    filtered.append(candidate)
            else:
                filtered.append(candidate)

        return filtered if filtered else candidates

    def _fine_tune_samples(self, candidates, row, missing_idx):
        """Fine-tune the selected samples"""
        if len(candidates) == 0:
            return candidates

        fine_tuned = []

        for candidate in candidates:
            # Fine-tune based on local density
            complete_mask = ~np.isnan(row)
            if np.sum(complete_mask) > 0:
                # Compute local density
                local_density = 0
                for other_idx in np.where(complete_mask)[0]:
                    if other_idx != missing_idx:
                        distance = abs(candidate - row[other_idx])
                        local_density += np.exp(-distance / np.std(self.X[:, missing_idx]))

                # Fine-tune based on density
                adjustment = 0.01 * local_density * np.random.normal(0, 1)
                fine_tuned.append(candidate + adjustment)
            else:
                fine_tuned.append(candidate)

        return fine_tuned

    def _select_best_candidate(self, candidates, row, missing_idx):
        """Select the best candidate sample"""
        if len(candidates) == 0:
            return self.mean[missing_idx]

        # Compute quality scores for each candidate
        scores = []
        for candidate in candidates:
            score = 0

            # Based on distance from the mean
            score -= abs(candidate - self.mean[missing_idx]) / np.std(self.X[:, missing_idx])

            # Based on consistency with existing features
            complete_mask = ~np.isnan(row)
            if np.sum(complete_mask) > 0:
                for other_idx in np.where(complete_mask)[0]:
                    if other_idx != missing_idx:
                        expected_cov = self.covariance[missing_idx, other_idx]
                        actual_cov = (candidate - self.mean[missing_idx]) * (row[other_idx] - self.mean[other_idx])
                        score -= abs(expected_cov - actual_cov)

            scores.append(score)

        # Select the candidate with the highest score
        best_idx = np.argmax(scores)
        return candidates[best_idx]

    def fit_transform(self, X):
        """Fit and transform the data"""
        return self.fit(X).transform(X)


def apply_joint_sampling_imputation(X, n_samples=5, covariance_threshold=0.8):
    """
    A convenience function to apply the multilevel joint sampling imputation strategy

    Parameters:
    X: Input data matrix with missing values (NaN)
    n_samples: Number of candidate samples to generate
    covariance_threshold: Covariance filtering threshold

    Returns:
    X_filled: Imputed data matrix
    """
    imputer = JointSamplingImputer(
        n_samples=n_samples,
        covariance_threshold=covariance_threshold
    )
    return imputer.fit_transform(X)
