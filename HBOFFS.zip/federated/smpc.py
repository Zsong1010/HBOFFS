import numpy as np

class SMPC:
    """
    Secure Multi-Party Computation (SMPC) based on additive secret sharing implementation.
    Supports inputs as list or np.ndarray, compatible with Paillier ciphertext objects.
    """
    def __init__(self, n_clients):
        self.n_clients = n_clients

    def share(self, data):
        """
        Split the data into n_clients shares and return a list of shares.
        Supports data as list or np.ndarray.
        If the data is a ciphertext object (e.g., Paillier EncryptedNumber), directly distribute the references without performing additive secret sharing.
        """
        # Check if it is a Paillier ciphertext (EncryptedNumber)
        if hasattr(data[0], 'ciphertext'):
            # Directly give each client a copy of the ciphertext (simulate ciphertext broadcasting)
            return [list(data) for _ in range(self.n_clients)]
        n = len(data)
        shares = []
        for _ in range(self.n_clients - 1):
            share = [np.random.randint(0, 2) for _ in range(n)]
            shares.append(share)
        final_share = [(int(data[i]) - sum(share[i] for share in shares)) % 2 for i in range(n)]
        shares.append(final_share)
        return shares

    def aggregate(self, all_shares):
        """
        Aggregate the shares from all clients to obtain the bitwise summation result.
        all_shares: List[List[list]], the outer list is for clients, and the inner list is the shares each client sends.
        """
        n_clients = len(all_shares)
        n_features = len(all_shares[0][0])
        # Check if it is Paillier ciphertext
        is_encrypted = hasattr(all_shares[0][0][0], 'ciphertext')
        if is_encrypted:
            # Ciphertext addition
            agg = [all_shares[0][0][k] for k in range(n_features)]
            for j in range(n_clients):
                for i in range(n_clients):
                    if i == 0 and j == 0:
                        continue  # Already initialized
                    for k in range(n_features):
                        agg[k] += all_shares[i][j][k]
            return agg
        else:
            # Plaintext addition
            agg = [0] * n_features
            for j in range(n_clients):
                for i in range(n_clients):
                    for k in range(n_features):
                        agg[k] += int(all_shares[i][j][k])
            return agg
