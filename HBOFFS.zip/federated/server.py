import numpy as np


class FederatedServer:
    """
    Federated Server, responsible for receiving encrypted features, SMPC aggregation, and returning the aggregation result.
    """

    def __init__(self, smpc):
        self.smpc = smpc
        self.agg_mask_enc = None
        self.agg_weights_enc = None

    def aggregate_masks_and_weights(self, client_uploads):
        """
        Aggregate the encrypted feature subsets, weight matrices, and indices uploaded by all clients.

        Parameters:
        client_uploads: List of data uploaded by clients, each element contains:
            - encrypted_mask: Encrypted feature mask
            - encrypted_weights: Encrypted feature weight matrix
            - feature_indices: Feature indices (unencrypted)
        """
        # Extract encrypted feature masks and weight matrices
        encrypted_masks = [upload['encrypted_mask'] for upload in client_uploads]
        encrypted_weights = [upload['encrypted_weights'] for upload in client_uploads]
        feature_indices_list = [upload['feature_indices'] for upload in client_uploads]

        # For encrypted data, directly perform ciphertext addition aggregation
        if hasattr(encrypted_masks[0][0], 'ciphertext'):
            # Ciphertext aggregation
            self.agg_mask_enc = self._aggregate_encrypted_data(encrypted_masks)
            self.agg_weights_enc = self._aggregate_encrypted_data(encrypted_weights)
        else:
            # Plaintext aggregation
            self.agg_mask_enc = np.mean(encrypted_masks, axis=0)
            self.agg_weights_enc = np.mean(encrypted_weights, axis=0)

        # Aggregate feature indices (based on frequency and importance)
        aggregated_indices = self._aggregate_feature_indices(feature_indices_list)

        return {
            'aggregated_mask_enc': self.agg_mask_enc,
            'aggregated_weights_enc': self.agg_weights_enc,
            'aggregated_indices': aggregated_indices
        }

    def _aggregate_encrypted_data(self, encrypted_data_list):
        """
        Aggregate encrypted data
        """
        n_clients = len(encrypted_data_list)
        n_features = len(encrypted_data_list[0])

        # Initialize the aggregation result
        agg_result = encrypted_data_list[0].copy()

        # Perform ciphertext addition for each feature
        for i in range(1, n_clients):
            for j in range(n_features):
                agg_result[j] += encrypted_data_list[i][j]

        return agg_result

    def _aggregate_feature_indices(self, feature_indices_list):
        """
        Aggregate feature indices based on the feature selection results from all clients
        """
        n_clients = len(feature_indices_list)

        # Count the frequency of each feature being selected
        feature_selection_frequency = {}
        feature_importance_scores = {}

        for indices in feature_indices_list:
            selected_features = indices['selected_features']
            feature_weights = indices['feature_weights']
            feature_importance = indices['feature_importance']

            for i, feat_idx in enumerate(selected_features):
                if feat_idx not in feature_selection_frequency:
                    feature_selection_frequency[feat_idx] = 0
                    feature_importance_scores[feat_idx] = []

                feature_selection_frequency[feat_idx] += 1
                feature_importance_scores[feat_idx].append(feature_importance[feat_idx])

        # Calculate aggregated feature indices
        aggregated_indices = {
            'feature_selection_frequency': feature_selection_frequency,
            'average_importance': {feat: np.mean(scores) for feat, scores in feature_importance_scores.items()},
            'n_clients': n_clients,
            'consensus_features': [feat for feat, freq in feature_selection_frequency.items() if freq > n_clients // 2]
        }

        return aggregated_indices

    def get_aggregation_summary(self):
        """
        Get the summary of the aggregation result
        """
        if self.agg_mask_enc is None or self.agg_weights_enc is None:
            return "Aggregation not performed yet"

        return {
            'mask_aggregated': self.agg_mask_enc is not None,
            'weights_aggregated': self.agg_weights_enc is not None,
            'status': 'Aggregation completed'
        }
