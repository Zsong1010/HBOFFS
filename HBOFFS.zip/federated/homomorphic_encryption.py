from phe import paillier
import numpy as np
import time

class PaillierHomomorphicEncryption:
    """
    Paillier homomorphic encryption implementation, with configurable key length,
    and statistics for encryption/decryption time and ciphertext size.
    """
    def __init__(self, key_length=2048):
        self.public_key, self.private_key = paillier.generate_paillier_keypair(n_length=key_length)
        self.key_length = key_length

    def encrypt(self, data: np.ndarray):
        start = time.time()
        enc_data = [self.public_key.encrypt(float(x)) for x in data.flatten()]
        enc_time = time.time() - start
        # Statistics for ciphertext size
        import sys
        size = sum(sys.getsizeof(x.ciphertext()) for x in enc_data)
        print(f"[Paillier] Encryption time: {enc_time:.4f}s, total ciphertext size: {size} bytes, key length: {self.key_length}")
        return enc_data

    def decrypt(self, enc_data):
        start = time.time()
        dec_data = np.array([self.private_key.decrypt(x) for x in enc_data])
        dec_time = time.time() - start
        print(f"[Paillier] Decryption time: {dec_time:.4f}s, key length: {self.key_length}")
        return dec_data
