import numpy as np
from sklearn.model_selection import train_test_split


class FederatedClient:
    """
    Federated Client, responsible for local feature selection, encrypted upload, and receiving aggregated results.
    """

    def __init__(self, X, y, encryption, test_size=0.2, random_state=42):
        self.X = X
        self.y = y
        self.encryption = encryption
        self.selected_mask = None
        self.feature_weights = None
        self.feature_indices = None

        # Split the data into training and testing sets with an 80:20 ratio
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )
        print(f"[Client] Data split completed: Training set {self.X_train.shape}, Test set {self.X_test.shape}")

    def local_feature_selection(self, fs_method, pop_size, max_iter, fitness_func, random_state=None):
        """
        Local feature selection, using the training data to perform feature selection. fs_method is the feature selection algorithm function.
        """
        # Perform feature selection using training data
        mask, score = fs_method(self.X_train, self.y_train, pop_size, max_iter, fitness_func, random_state)
        self.selected_mask = mask

        # Calculate feature weights and indices
        self.feature_weights, self.feature_indices = self._calculate_feature_weights_and_indices(mask)

        return mask, score

    def _calculate_feature_weights_and_indices(self, mask):
        """
        Calculate the feature weight matrix and feature indices
        """
        n_features = mask.shape[0]

        # Calculate feature importance (based on variance)
        feature_importance = np.var(self.X_train, axis=0)

        # Calculate feature weights (combine selection status and importance)
        feature_weights = mask * feature_importance

        # Normalize the weights
        if np.sum(feature_weights) > 0:
            feature_weights = feature_weights / np.sum(feature_weights)

        # Generate feature indices
        feature_indices = {
            'selected_features': np.where(mask == 1)[0].tolist(),
            'feature_weights': feature_weights.tolist(),
            'feature_importance': feature_importance.tolist(),
            'n_selected': int(np.sum(mask))
        }

        return feature_weights, feature_indices

    def upload_encrypted_mask(self):
        """
        Encrypt and upload the local optimal feature subset, weight matrix, and indices.
        """
        if self.selected_mask is None:
            raise ValueError("Please perform local feature selection first!")

        # Encrypt the feature mask
        encrypted_mask = self.encryption.encrypt(self.selected_mask)

        # Encrypt the feature weight matrix
        encrypted_weights = self.encryption.encrypt(self.feature_weights)

        # Feature indices do not need encryption (no sensitive information)

        return {
            'encrypted_mask': encrypted_mask,
            'encrypted_weights': encrypted_weights,
            'feature_indices': self.feature_indices
        }

    def receive_aggregated_mask(self, agg_result):
        """
        Receive the aggregated feature subset, weight matrix, and indices (decrypted) returned by the server.
        """
        self.selected_mask = agg_result['aggregated_mask']
        self.feature_weights = agg_result['aggregated_weights']
        self.feature_indices = agg_result['aggregated_indices']

        print(f"[Client] Received aggregated result: {np.sum(self.selected_mask)} features selected")

    def evaluate_on_test_set(self, classifier):
        """
        Evaluate the feature selection result on the test set
        """
        if self.selected_mask is None:
            raise ValueError("Please perform feature selection first!")

        # Use the selected features
        X_test_selected = self.X_test[:, self.selected_mask == 1]

        # Train the classifier
        classifier.fit(self.X_train[:, self.selected_mask == 1], self.y_train)

        # Evaluate on the test set
        test_score = classifier.score(X_test_selected, self.y_test)

        return test_score
