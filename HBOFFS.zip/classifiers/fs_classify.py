import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold
from xgboost import XGBClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, recall_score, f1_score
from sklearn.model_selection import GridSearchCV

def fs_classify(binary_pos, raw_data, classifier='ensemble', cv=3, weights=None, auto_param=True):
    """
    根据二进制特征选择向量和数据，支持多分类器集成、自动调参和多指标融合。
    参数：
        binary_pos: 二进制特征选择向量（1表示选中，0表示不选）
        raw_data: DataFrame或[train_df, test_df]，最后一列为标签
        classifier: 'XGB'/'KNN'/'SVM'/'ensemble'
        cv: 交叉验证折数
        weights: 分类器加权（ensemble时用）
        auto_param: 是否自动调参
    返回：
        acc, recall, f1: 分类准确率、召回率、F1-score
    """
    selected_attr = [i for i in range(len(binary_pos)) if binary_pos[i] == 1]
    if len(selected_attr) == 0:
        return 0.0, 0.0, 0.0
    if isinstance(raw_data, list):
        train_set = raw_data[0]
        test_set = raw_data[1]
        train_set_x = train_set.iloc[:, selected_attr]
        train_set_y = train_set.iloc[:, -1]
        test_set_x = test_set.iloc[:, selected_attr]
        test_set_y = test_set.iloc[:, -1]
    else:
        sample_data = raw_data.iloc[:, selected_attr]
        target_data = raw_data.iloc[:, -1]
        train_set_x, test_set_x, train_set_y, test_set_y = train_test_split(sample_data, target_data, test_size=0.3, stratify=target_data)
    results = []
    clfs = []
    names = []
    if classifier.upper() == 'ENSEMBLE':
        names = ['XGB', 'KNN', 'SVM']
    else:
        names = [classifier.upper()]
    for name in names:
        if name == 'XGB':
            if auto_param:
                param_grid = {'n_estimators':[50,100], 'max_depth':[3,5,7]}
                clf = GridSearchCV(XGBClassifier(eval_metric='mlogloss'), param_grid, cv=cv)
            else:
                clf = XGBClassifier(eval_metric='mlogloss')
        elif name == 'KNN':
            if auto_param:
                param_grid = {'n_neighbors':[3,5,7,9]}
                clf = GridSearchCV(KNeighborsClassifier(), param_grid, cv=cv)
            else:
                clf = KNeighborsClassifier()
        elif name == 'SVM':
            if auto_param:
                param_grid = {'kernel':['rbf','linear','poly']}
                clf = GridSearchCV(SVC(), param_grid, cv=cv)
            else:
                clf = SVC()
        else:
            raise ValueError('未知分类器类型')
        clf.fit(train_set_x, train_set_y)
        predict_y = clf.predict(test_set_x)
        acc = accuracy_score(test_set_y, predict_y)
        recall = recall_score(test_set_y, predict_y, average='macro')
        f1 = f1_score(test_set_y, predict_y, average='macro')
        results.append((acc, recall, f1))
        clfs.append(clf)
    # 只取最优结果
    if len(results) > 1:
        best_idx = np.argmax([r[0] for r in results])
        acc, recall, f1 = results[best_idx]
    else:
        acc, recall, f1 = results[0]
    return acc, recall, f1 