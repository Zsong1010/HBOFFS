from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, recall_score, f1_score

def knn_classify(X_train, y_train, X_test, y_test, n_neighbors=5):
    """
    KNN classifier training and evaluation.
    Parameters:
        X_train, y_train: Training set
        X_test, y_test: Test set
        n_neighbors: Number of neighbors
    Returns:
        acc, recall, f1: Classification accuracy, recall, F1-score
    """
    clf = KNeighborsClassifier(n_neighbors=n_neighbors)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred, average='macro')
    f1 = f1_score(y_test, y_pred, average='macro')
    return acc, recall, f1
