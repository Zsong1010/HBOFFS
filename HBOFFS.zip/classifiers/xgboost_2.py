from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, recall_score, f1_score

def xgb_classify(X_train, y_train, X_test, y_test):
    """
    XGBoost classifier training and evaluation.
    Parameters:
        X_train, y_train: Training set
        X_test, y_test: Test set
    Returns:
        acc, recall, f1: Classification accuracy, recall, F1-score
    """
    clf = XGBClassifier(use_label_encoder=False, eval_metric='mlogloss')
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred, average='macro')
    f1 = f1_score(y_test, y_pred, average='macro')
    return acc, recall, f1
